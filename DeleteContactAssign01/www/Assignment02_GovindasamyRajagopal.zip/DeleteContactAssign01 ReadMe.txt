
Govindasamy Rajagopal
rgoveena@yahoo.com

Zip File name: Assignment02_GovindasamyRajagopal.zip

contents:
1. WWW folder 
2. DeleteContactAssign01 Readme.txt

Steps: 
=====

$ cordova create DeleteContactAssign01 com.ucsc.contacts.api.DeleteContactAssign01 DeleteContactAssign01

cd DeleteContactAssign01

Replace the WWW folder from the zip file 



$ cordova platform add ios 

$ cordova plugin add org.apache.cordova.console

$ cordova plugin add org.apache.cordova.dialogs

$ cordova plugin add org.apache.cordova.contacts

$ cordova run 

